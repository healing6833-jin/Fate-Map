/**
 * 훼이맵 리포트 → 블로그 초안 변환기
 * ------------------------------------------------------
 * 이미 생성된 상담 리포트(.docx)를 읽어 pandoc으로 텍스트 추출 후,
 * 섹션을 파싱하여 블로그 포스트 초안(마크다운 골격)으로 변환합니다.
 *
 * (엑셀에서 직접 만드는 generate_content_draft.js와 달리,
 *  이미 배포/보관 중인 리포트 "파일" 자체를 원본으로 사용하고 싶을 때 씁니다.)
 *
 * 사용법:
 *   node report_to_blog_draft.js [리포트폴더]   기본값: ./reports
 *   출력: ./content_drafts_from_reports/*.md
 *
 * 요구사항: pandoc 설치 필요 (docx → 텍스트 추출용)
 */

const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const reportsDir = process.argv[2] || "./reports";
const outDir = "./content_drafts_from_reports";

if (!fs.existsSync(reportsDir)) {
  console.error(`리포트 폴더를 찾을 수 없습니다: ${reportsDir}`);
  process.exit(1);
}
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

const HOOK_BY_KEYWORD = [
  [/사업|수익|협업/, "일과 방향에 대한 고민"],
  [/관계|파트너/, "관계에서 반복되는 패턴"],
  [/건강/, "몸과 마음의 신호"],
  [/시기|타이밍/, "지금 이 시기가 갖는 의미"],
  [/자기|성향|기질/, "나도 몰랐던 나의 기질"],
  [/위기|전환/, "흔들리는 시기를 지나는 법"],
  [/영성|내면/, "내면 깊은 곳의 목소리"],
];

function guessHook(topic) {
  for (const [re, hook] of HOOK_BY_KEYWORD) {
    if (re.test(topic)) return hook;
  }
  return "삶의 흐름을 읽는 법";
}

// ---------- docx → 텍스트 추출 ----------
function extractText(docxPath) {
  return execSync(`pandoc -t plain --wrap=none "${docxPath}"`, { encoding: "utf-8" });
}

// ---------- 섹션 파싱 (상태 기계) ----------
function parseReport(text) {
  const lines = text.split("\n").map((l) => l.trim());
  const data = {
    clientName: "",
    clientId: "",
    sessionNumber: "",
    sessionDate: "",
    topic: "",
    keyPoints: [],
    prescription: "",
    nextSteps: [],
    nextSessionDate: "",
    ohengLine: "",
  };

  // "제 N회 상담 | 2026-01-15"
  const headerLine = lines.find((l) => /^제\s*\d+회\s*상담/.test(l));
  if (headerLine) {
    const m = headerLine.match(/제\s*(\d+)회\s*상담\s*\|\s*(.+)/);
    if (m) {
      data.sessionNumber = m[1];
      data.sessionDate = m[2].trim();
    }
  }

  const nameLine = lines.find((l) => /^이름\s+/.test(l));
  if (nameLine) {
    const m = nameLine.match(/^이름\s+(.+?)\s*\(([^)]+)\)/);
    if (m) {
      data.clientName = m[1].trim();
      data.clientId = m[2].trim();
    }
  }

  const ohengLine = lines.find((l) => /^오행 분포/.test(l));
  if (ohengLine) data.ohengLine = ohengLine.replace(/^오행 분포\s*/, "").trim();

  // 섹션 인덱스 찾기
  const idx = (label) => lines.findIndex((l) => l === label);
  const idxTopic = idx("이번 상담 주제");
  const idxKey = idx("핵심 분석 내용");
  const idxRx = idx("처방");
  const idxNext = idx("다음 단계 / 과제");
  const idxNextDateLine = lines.findIndex((l) => l.startsWith("다음 상담 예정일"));

  if (idxTopic >= 0) {
    const rest = lines.slice(idxTopic + 1, idxKey >= 0 ? idxKey : idxTopic + 3).filter(Boolean);
    data.topic = rest[0] || "";
  }
  if (idxKey >= 0) {
    const end = idxRx >= 0 ? idxRx : lines.length;
    data.keyPoints = lines
      .slice(idxKey + 1, end)
      .filter((l) => l.startsWith("-"))
      .map((l) => l.replace(/^-+\s*/, ""));
  }
  if (idxRx >= 0) {
    const end = idxNext >= 0 ? idxNext : lines.length;
    data.prescription = lines.slice(idxRx + 1, end).filter(Boolean).join(" ");
  }
  if (idxNext >= 0) {
    const end = idxNextDateLine >= 0 ? idxNextDateLine : lines.length;
    data.nextSteps = lines
      .slice(idxNext + 1, end)
      .filter((l) => l.startsWith("-"))
      .map((l) => l.replace(/^-+\s*/, ""));
  }
  if (idxNextDateLine >= 0) {
    const m = lines[idxNextDateLine].match(/다음 상담 예정일:\s*(.+)/);
    if (m) data.nextSessionDate = m[1].trim();
  }

  return data;
}

// ---------- 블로그 초안 골격 생성 ----------
function buildDraft(data, sourceFile) {
  const hook = guessHook(data.topic);
  const titleCandidates = [
    `${hook}, 사주는 어떻게 답할까`,
    `${data.topic} — 흐름을 읽는 시선`,
    `왜 지금 이 시기가 중요한가: ${data.topic}`,
  ];

  return `---
draft: true
source_report: "${sourceFile}"
client: "${data.clientName} (${data.clientId})"
session: "${data.sessionNumber}회차 / ${data.sessionDate}"
status: "AI 초안 - 검수 필요"
---

# [제목 후보 - 택1 또는 재작성]
${titleCandidates.map((t) => `- ${t}`).join("\n")}

## 도입부 (훅)
> [ TODO: "${hook}"을 소재로 독자의 공감을 끄는 1~2문단 작성 ]

## 본문 1 — 무엇이 보이는가
${data.keyPoints.length ? data.keyPoints.map((p) => `- ${p}`).join("\n") : "- [핵심 내용 없음]"}

(참고: 오행 분포 — ${data.ohengLine || "정보 없음"})

[ TODO: 위 포인트를 자연스러운 문단으로 풀어 쓰기 ]

## 본문 2 — 처방과 실천
${data.prescription ? `현재 제안하는 처방: **${data.prescription}**` : "[ 처방 정보 없음 ]"}

[ TODO: 이 처방이 왜 이 상황에 맞는지 1문단으로 설명 ]

## 다음 단계
${data.nextSteps.length ? data.nextSteps.map((s, i) => `${i + 1}. ${s}`).join("\n") : "- [다음 단계 없음]"}

## 마무리
[ TODO: 독자에게 남기는 메시지 1~2문장 ]

---
*(내부 메타) 원본 리포트: ${sourceFile} / ${data.topic} / ${data.sessionDate}*
`;
}

// ---------- 실행 ----------
const docxFiles = fs.readdirSync(reportsDir).filter((f) => f.endsWith(".docx"));
if (docxFiles.length === 0) {
  console.log(`${reportsDir} 안에 .docx 리포트가 없습니다.`);
  process.exit(0);
}

let count = 0;
for (const file of docxFiles) {
  const fullPath = path.join(reportsDir, file);
  try {
    const text = extractText(fullPath);
    const data = parseReport(text);
    const md = buildDraft(data, file);
    const outName = `blogdraft_${path.basename(file, ".docx")}.md`;
    fs.writeFileSync(path.join(outDir, outName), md, "utf-8");
    console.log(`변환됨: ${file} → ${outName}`);
    count++;
  } catch (e) {
    console.error(`실패: ${file} — ${e.message}`);
  }
}

console.log(`\n총 ${count}개 리포트를 블로그 초안으로 변환 완료 → ${outDir}`);
